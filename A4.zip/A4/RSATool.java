

/**
 * This class provides an implementation of 1024-bit RSA-OAEP.
 * CPSC 418 A4
 * @author Asjad Malick
 * 30002229
 */

//Necessary imports
import java.math.*;
import java.security.*;
import java.util.Arrays;

public class RSATool {
	// OAEP constants
	private final static int K = 128;  // size of RSA modulus in bytes
	private final static int K0 = 16;  // K0 in bytes
	private final static int K1 = 16;  // K1 in bytes

	// RSA key data
	private BigInteger n;
	private BigInteger e, d, p, q;


	// SecureRandom for OAEP and key generation
	private SecureRandom rnd;
	private boolean debug = false;

	//The byte array storing the zeroes 
	private static byte[] k1Zeros = new byte[K1];
	
	/**
	 * Utility for printing protocol messages
	 * @param s protocol message to be printed
	 */
	private void debug(String s) {
		if(debug) 
			System.out.println("Debug RSA: " + s);
	}

	/**
	 * G(M) = 1st K-K0 bytes of successive applications of SHA1 to M
	 */
	private byte[] G(byte[] M) {
		MessageDigest sha1 = null;
		try {
			sha1 = MessageDigest.getInstance("SHA1");
		}
		catch (NoSuchAlgorithmException e) {
			System.out.println(e);
			System.exit(1);
		}


		byte[] output = new byte[K-K0];
		byte[] input = M;

		int numBytes = 0;
		while (numBytes < K-K0) {
			byte[] hashval = sha1.digest(input);

			if (numBytes + 20 < K-K0)
				System.arraycopy(hashval,0,output,numBytes,K0);
			else
				System.arraycopy(hashval,0,output,numBytes,K-K0-numBytes);

			numBytes += 20;
			input = hashval;
		}

		return output;
	}


	/**
	 * H(M) = the 1st K0 bytes of SHA1(M)
	 */
	private byte[] H(byte[] M) {
		MessageDigest sha1 = null;
		try {
			sha1 = MessageDigest.getInstance("SHA1");
		}
		catch (NoSuchAlgorithmException e) {
			System.out.println(e);
			System.exit(1);
		}

		byte[] hashval = sha1.digest(M);

		byte[] output = new byte[K0];
		System.arraycopy(hashval,0,output,0,K0);

		return output;
	}



	/**
	 * Construct instance for decryption.  Generates both public and private key data.
	 *
	 * TODO: implement key generation for RSA as per the description in your write-up.
	 *   Include whatever extra data is required to implement Chinese Remainder
	 *   decryption as described in Problem 2.
	 */
	public RSATool(boolean setDebug) {
		// set the debug flag
		debug = setDebug;

		rnd = new SecureRandom();

		// TODO:  include key generation implementation here (remove init of d)

		//Randomly generate p and q
		p = new BigInteger(511, 3, rnd);
		q = new BigInteger(511, 3, rnd);
		//Calculate n = p*q
		n = p.multiply(q);

		//Calculate phi of n = (p-1) * (q-1)
		BigInteger phiN = (p.subtract(BigInteger.ONE)).multiply( (q.subtract(BigInteger.ONE)) );

		//Loop control
		boolean run = true;
		BigInteger test = BigInteger.TEN;
		
		//The loop will generate a valid e as defined by RSA
		while(run)
		{	
			do {
				test = new BigInteger(phiN.bitLength(), rnd);
			} while (test.compareTo(n) >= 0 || test.compareTo(BigInteger.ZERO) == 0);

			if( (test.gcd(phiN)).compareTo(BigInteger.ONE) == 0)
				//If value checks pass exit loop 
				run = false;
		}

		//If the loop breaks, test is a good e value
		e = test;
		
		//Calculate secret key d
		d = e.modInverse(phiN);
	}


	/**
	 * Construct instance for encryption, with n and e supplied as parameters.  No
	 * key generation is performed - assuming that only a public key is loaded
	 * for encryption.
	 */
	public RSATool(BigInteger new_n, BigInteger new_e, boolean setDebug) {
		// set the debug flag
		debug = setDebug;

		// initialize random number generator
		rnd = new SecureRandom();

		//Set n and e to be what was given
		n = new_n;
		e = new_e;
	}

	public BigInteger get_n() {
		return n;
	}

	public BigInteger get_e() {
		return e;
	}

	/**
	 * Encrypts the given byte array using RSA-OAEP.
	 *
	 * TODO: implement RSA encryption
	 *
	 * @param plaintext  byte array representing the plaintext
	 * @throw IllegalArgumentException if the plaintext is longer than K-K0-K1 bytes
	 * @return resulting ciphertext
	 */
	public byte[] encrypt(byte[] plaintext) {
		debug("In RSA encrypt");

		// make sure plaintext fits into one block
		if (plaintext.length > K-K0-K1)
			throw new IllegalArgumentException("plaintext longer than one block");

		// TODO:  implement RSA-OAEP encryption here (replace following return statement)

		//Get the amount of zeroes that need to be added to the plaintext (its always gonna be 16 bytes)
		int length = (K-K0-K1);
		k1Zeros = new byte[length];

		//Set loop control boolean
		boolean run = true;

		//initialize variable to store the result of the loop
		BigInteger preCipherText = BigInteger.TEN;

		//The loop will get a valid (s || t)
		while(run)
		{
			//Random number r
			BigInteger r = new BigInteger((K0 * 8)-1, this.rnd);

			//Pad 0's to M
			byte[] concatMand0 = new byte[plaintext.length + k1Zeros.length];
			System.arraycopy(plaintext, 0, concatMand0, 0 ,plaintext.length);
			System.arraycopy(k1Zeros, 0 , concatMand0, plaintext.length, k1Zeros.length);

			//Get s and t values
			byte[] GofR = this.G(r.toByteArray());
			byte[] s = this.XOR(concatMand0, GofR);
			byte[] t = this.XOR(r.toByteArray(), this.H(s));

			//Concatenate s and t
			byte[] concatSandT = new byte[s.length + t.length];
			System.arraycopy(s, 0, concatSandT, 0, s.length);
			System.arraycopy(t, 0, concatSandT, s.length, t.length);

			//Convert concatenated array into a number and check its value
			BigInteger sAndTInteger = new BigInteger(concatSandT);

			if((sAndTInteger.compareTo(n) < 0) && (sAndTInteger.compareTo(BigInteger.ZERO) > 0))
			{
				//If value checks pass, break the loop and set number to be preciphertext
				run = false;
				preCipherText = sAndTInteger;
			}
		}
		
		
		//RSA encrypt the cipher-text
		BigInteger cipherText = preCipherText.modPow(e, n);
		
		//Return the byte array
		return cipherText.toByteArray();
	}

	/**
	 * Decrypts the given byte array using RSA.
	 *
	 * TODO:  implement RSA-OAEP decryption using the Chinese Remainder method described in Problem 2
	 *
	 * @param ciphertext  byte array representing the ciphertext
	 * @throw IllegalArgumentException if the ciphertext is not valid
	 * @throw IllegalStateException if the class is not initialized for decryption
	 * @return resulting plaintexttext
	 */
	public byte[] decrypt(byte[] ciphertext) {
		debug("In RSA decrypt");

		//Make sure k1 zeroes are of appropriate length of 
		int length = (K-K0-K1);
		k1Zeros = new byte[length];
		
		// make sure class is initialized for decryption
		if (d == null)
			throw new IllegalStateException("RSA class not initialized for decryption");

		// TODO:  implement RSA-OAEP decryption here (replace following return statement)

		//Do the RSA decryption 
		BigInteger cipherInteger = new BigInteger(ciphertext);
		
		//Chinese remainder
		//The next steps implement chinese remainder decryption
		BigInteger dp = d.mod(p.subtract(BigInteger.ONE));
		BigInteger dq = d.mod(q.subtract(BigInteger.ONE));
		
		BigInteger mp = cipherInteger.modPow(dp, p);
		BigInteger mq = cipherInteger.modPow(dq, q);
		
		BigInteger[] xAndy = EEA(p,q);
		
		BigInteger arg1 = p.multiply(xAndy[0]);
		arg1 = arg1.multiply(mq);
		
		BigInteger arg2 = q.multiply(xAndy[1]);
		arg2 = arg2.multiply(mp);
		
		BigInteger arg = arg1.add(arg2);
		
		BigInteger concatSandTInteger = arg.mod(n);
		//BigInteger concatSandTInteger = cipherInteger.modPow(d, n);
		
		//Get the byte array of s||t
		byte[] concatSandT = concatSandTInteger.toByteArray();

		//Split concatenated byte array into s and t
		byte[] t = new byte[K0];
		byte[] s = new byte[K - K0];
		s = Arrays.copyOfRange(concatSandT, 0, s.length);
		t = Arrays.copyOfRange(concatSandT, s.length, concatSandT.length);

		//create arrays v and u
		byte[] u = this.XOR(t, this.H(s));
		byte[] v = this.XOR(s, this.G(u));

		//Boolean to decide whether to accept or reject ciphertext
		boolean valid = true;
		
		//Loop to see if padding is intact
		for(int i = v.length - 1, j = 0; j < k1Zeros.length; i--, j++)
		{
			//Get the byte
			byte x = v[i];
			
			//If it is not 0, then the array is not a valid plaintext
			if(x != 0)
			{
				valid = false;
				j = K1;
			}
		}

		if(valid)
		{
			//Remove the 0's and return plaintext.
			byte[] m = Arrays.copyOfRange(v, 0, (v.length - length));
			return m;
		}
		//Return null otherwise
		return null;
	}

	//Custom XOR method, return the XOR of 2 input byte arrays a and b
	public byte[] XOR(byte[] a, byte[] b)
	{
		byte[] c = new byte[0];
		if(a.length == b.length)
		{
			c = new byte[a.length];

			for(int i = 0; i < a.length; i++)
			{
				byte xor = (byte) (a[i] ^ b[i]);
				c[i] = xor;
			}
		}
		return c;
	}
	
	/**
	 * Custom method to use extended euclidean algorithm to get x and y
	 * @param a the first number
	 * @param b the second number
	 * @return a biginteger with and x and y in indicies  0 and 1 such that
	 * xa + yb = 1
	 * Obtained from
	 * http://www.sanfoundry.com/java-program-extended-euclid-algorithm/
	 */
	public BigInteger[] EEA (BigInteger a, BigInteger b)
	{
		BigInteger[] ret = new BigInteger[2];
		
		BigInteger x = BigInteger.ZERO;
		BigInteger y = BigInteger.ONE;
		
		BigInteger lastx = BigInteger.ONE;
		BigInteger lasty = BigInteger.ZERO;
		
		BigInteger newA = new BigInteger(a.toByteArray());
		BigInteger newB = new BigInteger(b.toByteArray());
		
		BigInteger temp;
		
		while(newB.compareTo(BigInteger.ZERO) != 0)
		{
			BigInteger q = newA.divide(newB);
			BigInteger r = newA.mod(newB);
			
			newA = newB;
			newB = r;
			
			temp = x;
			x = lastx.subtract( q.multiply(x) );
			lastx = temp;
			
			
			temp = y;
			y = lasty.subtract( q.multiply(y) );
			lasty = temp;
		}
		
		ret[0] = lastx;
		ret[1] = lasty;
		return ret;
	}
}

