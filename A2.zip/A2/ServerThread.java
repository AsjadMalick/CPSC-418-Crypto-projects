
/**
 * CPSC 418 Assignment 2
 * F17
 * @author Asjad Hassan Malick 30002229
 */
import javax.crypto.spec.SecretKeySpec;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Thread to deal with clients who connect to Server.  Put what you want the
 * thread to do in it's run() method.
 */

public class ServerThread extends Thread
{
    private Socket sock;  //The socket it communicates with the client on.
    private Server parent;  //Reference to Server object for message passing.
    private int idnum;  //The client's id number.
    private String key;
    private boolean debug;

    /**
     * Constructor, does the usual stuff.
     *
     * @param s  Communication Socket.
     * @param p  Reference to parent thread.
     * @param id ID Number.
     */
    public ServerThread(Socket s, Server p, int id, String k, boolean dbug)
    {
    	//Initialize parameters
        parent = p;
        sock = s;
        idnum = id;
        key = k;
        debug = dbug;
    }

    /**
     * Getter for id number.
     *
     * @return ID Number
     */
    public int getID()
    {
        return idnum;
    }

    /**
     * Getter for the socket, this way the parent thread can
     * access the socket and close it, causing the thread to
     * stop blocking on IO operations and see that the server's
     * shutdown flag is true and terminate.
     *
     * @return The Socket.
     */
    public Socket getSocket()
    {
        return sock;
    }

    /**
     * This is what the thread does as it executes.  Listens on the socket
     * for incoming data and then echos it to the screen.  A client can also
     * ask to be disconnected with "exit" or to shutdown the server with "die".
     */
    public void run()
    {
        BufferedReader in = null;
        String incoming;
        PrintWriter pw;
        try
        {
        	//Iniitalize stream readers/outputters
            in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
            pw = new PrintWriter(sock.getOutputStream());
        } catch (UnknownHostException e)
        {
            System.out.println("Unknown host error.");
            return;
        } catch (IOException e)
        {
            System.out.println("Could not establish communication.");
            return;
        }

		/* Try to read from the socket */
        try
        {
            incoming = in.readLine();
        } catch (IOException e)
        {
            if (parent.getFlag())
            {
                System.out.println("shutting down.");
                return;
            }
            return;
        }
        /* See if we've received something */
        while (incoming != null)
        {
            /* If the client has sent "exit", instruct the server to
             * remove this thread from the vector of active connections.
			 * Then close the socket and exit.
			 */
            if (incoming.equals("exit"))
            {
                parent.kill(this);
                try
                {
                    in.close();
                    pw.close();
                    sock.close();
                } catch (IOException e)
                {/*nothing to do*/}
                return;
            }
            /* If the client has sent "die", instruct the server to
             * signal all threads to shutdown, then exit.
			 */
            else if (incoming.equals("die"))
            {
                parent.killall();
                return;
            } 
            else
            {
                try
                {
                    //Decryption here 
                	
                	//Initialize key
                    SecretKeySpec key = CryptoUtilities.key_from_seed(this.key.getBytes());


                    //Get bytes of message into array form
                    String[] incomingBytesStringArray = incoming.substring(1, incoming.length() - 1).split(", ");
                    byte[] incomingBytesArray = new byte[incomingBytesStringArray.length];
                    
                    for(String i : incomingBytesStringArray)
                        System.out.print(i);

                    //Convert the array for string bytes into an array of bytes
                    for (int counter = 0; counter < incomingBytesStringArray.length; counter++)
                        incomingBytesArray[counter] = Byte.parseByte(incomingBytesStringArray[counter]);
                    
                    //Decrypt the byte array
                    byte[] encryptedMessageAndDigest = incomingBytesArray;
                    byte[] decryptedMessageAndDigest = CryptoUtilities.decrypt(encryptedMessageAndDigest, key);
                    byte[] decryptedMessage = CryptoUtilities.extract_message(decryptedMessageAndDigest);
                    
                    //Prepare response to client
                    String response = "";
                    
                    //Debug protocol message
                    if(debug)
                    	System.out.println("Debug SERVER: Message Received");
                    
                    //If the hash is verified go into if, otherwise execute the else
                    if(CryptoUtilities.verify_hash(decryptedMessageAndDigest, key))
                    {
                    	//Begin constructing response
                    	response = "Message Digest verified, ";
                    	
                    	//Debug protocol message
                    	if(debug)
                    		System.out.println("Debug SERVER: Digest Verified");
                    	
                    	//Convert to string
                    	String decryptedString = new String(decryptedMessage);
                    	
                    	//Split at special header character sequence
                    	String decryptedSections[] = decryptedString.split("3nd0fh34d3r", 2);
                    	
                    	//Get different sections
                    	String[] headerSections = decryptedSections[0].split(",");
                    	
                    	//Debug protocol message
                    	if(debug)
                    		System.out.println("Server DEBUG: Length of file " + headerSections[1]);
                    	
                    	//Store the plaintext separate from the header info
                    	byte[] plainTextBytes = decryptedSections[1].getBytes();
                    	try 
                    	{
                    		//Write plaintext to file
							FileOutputStream fos = new FileOutputStream(headerSections[0]);
							fos.write(plainTextBytes);
							fos.close();
							
							//Add to response
							response = response + "File successfully written";
							
							//Debug protocol message
							if(debug)
	                    		System.out.println("Debug SERVER: File write successful");
	                    	
						} 
                    	catch (IOException e) 
                    	{
                    		//Protocol message
                    		if(debug)
	                    		System.out.println("Debug SERVER: File write unsuccessful");
                    		
                    		//Construct response
							response = response + "Error while writing File"; 
						}
                    	
                    	//Send back constructed response
                    	pw.print(response + "\n");
                    	pw.flush();
                    	
                    }
                    else
                    {
                    	//Protocol response
                    	if(debug)
                    		System.out.println("Debug SERVER: Message Digest failed");
                    	
                    	//Send back constructed response
                    	response = "Message Digest failed verification";
                    	pw.print(response + "\n");
                    	pw.flush();
                    }

                    
                } catch (StringIndexOutOfBoundsException | NumberFormatException | NullPointerException e)
                {
                	//Ignore these exceptions
                }
                
                // Try to read the next line if possible
                try
                {
                    incoming = in.readLine();
                } catch (IOException e)
                {
                    if (parent.getFlag())
                    {
                        System.out.println("shutting down.");
                        return;
                    } else
                    {
                        System.out.println("IO Error.");
                        return;
                    }
                }
            }
        }
    }
}
