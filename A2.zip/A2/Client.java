

/**
 * CPSC 418 Assignment 2
 * F17
 * @author Asjad Hassan Malick 30002229
 */
import javax.crypto.spec.SecretKeySpec;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Client program.  Connects to the server and sends text accross.
 */
public class Client
{
	private Socket sock;  //Socket to communicate with.

	/**
	 * Main method, starts the client.
	 *
	 * @param args args[0] needs to be a hostname, args[1] a port number. Optional args[2] is debug
	 */
	public static void main(String[] args)
	{
		boolean debug = false;
		
		//See if debug was given as a parameter and see if arguments are in correct format
		if(args.length == 3)
			if(args[2].equals("debug"))
				debug = true;
			else
			{
				System.out.println ("Usage: java Client hostname port# OR java Client hostname port# debug");
				System.out.println ("hostname is a string identifying your server");
				System.out.println ("port is a positive integer identifying the port to connect to the server");
				return;
			}

		else
		{
			if (args.length != 2) {
				System.out.println ("Usage: java Client hostname port#");
				System.out.println ("hostname is a string identifying your server");
				System.out.println ("port is a positive integer identifying the port to connect to the server");
				return;
			}
		}

		try
		{
			//Echo the provided inputs
			System.out.println("Hostname: "+args[0]);
			System.out.println("Port#: " + args[1]);
			System.out.println("Debug: " + debug);

			//prompt key
			Scanner kbReader = new Scanner(System.in);
			System.out.println("Please enter key to use:");
			String key = kbReader.nextLine();

			//prompt for source file
			System.out.println("Please enter source file name:" );
			String srcFile = kbReader.nextLine();

			//prompt for destination file
			System.out.println("Please enter destination file name:");
			String destFile = kbReader.nextLine();
			kbReader.close();

			//If the source file exists then create client, otherwise throw exception
			if(new File(srcFile).exists())
			{
				//Create client
				Client c = new Client(args[0], Integer.parseInt(args[1]), srcFile, destFile, key, debug);
			}
			else
			{
				throw new IOException();
			}

		} catch (NumberFormatException e)
		{
			System.out.println("Usage: java Client hostname port#");
			System.out.println("Second argument was not a port number");
			return;
		} catch (IOException e) {
			System.out.println("Source File does not exist");
		}
	}

	/**
	 * Constructor, in this case does everything.
	 *
	 * @param ipaddress The hostname to connect to.
	 * @param port      The port to connect to.
	 */
	public Client(String ipaddress, int port, String src, String dest, String k, boolean dbug)
	{
		/* Allows us to get input from the keyboard. */
		BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
		String userinput;
		PrintWriter out;

		/* Try to connect to the specified host on the specified port. */
		try
		{
			sock = new Socket(InetAddress.getByName(ipaddress), port);
		} catch (UnknownHostException e)
		{
			System.out.println("Usage: java Client hostname port#");
			System.out.println("First argument is not a valid hostname");
			return;
		} catch (IOException e)
		{
			System.out.println("Could not connect to " + ipaddress + ".");
			return;
		}

		/* Status info */
		System.out.println("Connected to " + sock.getInetAddress().getHostAddress() + " on port " + port);

		try
		{
			//Get output stream
			out = new PrintWriter(sock.getOutputStream());

			//Set up fileinput
			FileInputStream input = new FileInputStream(src);
			File plain = new File(src);

			//Read bytes from file
			byte[] msg = new byte[input.available()];
			int read_bytes = input.read(msg);

			//Generate key
			SecretKeySpec key = CryptoUtilities.key_from_seed(k.getBytes());

			//Create header and concatenate with plaintext
			byte[] header = (dest + "," + plain.length() + "3nd0fh34d3r").getBytes();
			byte[] payload = new byte[header.length + msg.length];
			System.arraycopy(header, 0, payload, 0, header.length);
			System.arraycopy(msg, 0, payload, header.length, msg.length);
			
			//Append the hash
			byte[] rawMessageAndDigest = CryptoUtilities.append_hash(payload, key);
			
			//Encrypt the hashed messaged
			byte[] encryptedStringBytes = CryptoUtilities.encrypt(rawMessageAndDigest, key);

			// Creates an ASCII string of the array of encrypted bytes
			String encryptedBytesString = Arrays.toString(encryptedStringBytes);
			input.close();

			//Send the ASCII array to server
			out.print(encryptedBytesString + "\n");
			out.flush();
			
			//Debug protocol
			if(dbug)
				System.out.println("Encrypted Message sent");

			// Setup inputStream for server response
			BufferedReader inServer = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			
			//Attempt to read response
			String response = inServer.readLine();

			//Debug protocol
			if(dbug)
				System.out.println("DEBUG Client: " + response + "received from Server");

			//If the response contains information of message digest
			if(response.contains("Message Digest"))
			{
				//Print out acknowledgment
				System.out.println("Client: acknowledgement received from server");

				//Kill client
				System.out.println("Client exiting.");
				try {
					stdIn.close();
					inServer.close();
					sock.close();
					return;
				} 
				catch (IOException e1) 
				{
					return;
				}
			}
		} catch (IOException e)
		{
			System.out.println("Could not create output stream."); 
			return;
		}

		/* Wait for the user to type stuff. */
		try
		{
			while ((userinput = stdIn.readLine()) != null)
			{
				/* Echo it to the screen. */
				out.println(userinput);

				/* Tricky bit.  Since Java does short circuiting of logical
				 * expressions, we need to checkerror to be first so it is always
				 * executes.  Check error flushes the outputstream, which we need
				 * to do every time after the user types something, otherwise,
				 * Java will wait for the send buffer to fill up before actually
				 * sending anything.  See PrintWriter.flush().  If checkerror
				 * has reported an error, that means the last packet was not
				 * delivered and the server has disconnected, probably because
				 * another client has told it to shutdown.  Then we check to see
				 * if the user has exitted or asked the server to shutdown.  In
				 * any of these cases we close our streams and exit.
				 */
				if ((out.checkError()) || (userinput.compareTo("exit") == 0) || (userinput.compareTo("die") == 0))
				{
					System.out.println("Client exiting.");
					stdIn.close();
					out.close();
					sock.close();
					return;
				}
			}
		} catch (IOException e)
		{
			System.out.println("Could not read from input.");
			return;
		}
	}
}
