
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.FileInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

/*
 * decryptFile.java
 * Asjad Malick
 * 30002229
 * CPSC 418 A1
 */

public class decryptFile
{
	// Specifies the IV spec for the AES key
    private static byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    private static IvParameterSpec ivSpec = new IvParameterSpec(iv);

    public static void main(String args[])
    {
        // Initializes the data stream for the encrypted input file
        FileInputStream inputFileStream = null;

        // Surrounds the code with a try / catch statement to handle any errors
        try
        {
            // Creates a data stream for the encrypted input file
            inputFileStream = new FileInputStream(args[0]);

            // Reads the input file's encrypted data into a byte array
            byte[] inputEncryptedDataBytes = new byte[inputFileStream.available()];
            inputFileStream.read(inputEncryptedDataBytes);

            // Gets the user defined seed from the command line argument's passed and stores it
            String seed = args[1];
            
            // Gets the byte array of the hash of user defined seed
            byte[] seedHash = sha1_hash(seed.getBytes());

            // Uses the user defined seed to create a 16 byte (128 bit) array
            byte[] seedBytes = Arrays.copyOf(seedHash, 16);//(seed.getBytes(), 16);

            // Creates a new AES key using the provided byte array of the provided seed
            SecretKey generatedKey = new SecretKeySpec(seedBytes, "AES");

            // Makes a data decrypter
            Cipher decrypt = Cipher.getInstance("AES/CBC/PKCS5Padding");
            decrypt.init(Cipher.DECRYPT_MODE, generatedKey, ivSpec);

            // Decrypts the byte array of the string
            byte[] decryptedCombinedDataBytes = decrypt.doFinal(inputEncryptedDataBytes);

            // Separates the message from its SHA-1 hash and stores both individually as byte arrays
            // 59 is used since the hex string of sha + the : is 59 characters 
            byte[] decryptedDataBytes = 
            		new String(decryptedCombinedDataBytes).substring
            			(0, new String(decryptedCombinedDataBytes).length() - 59).getBytes();
            
            
            byte[] decryptedShaHashBytes = 
            		new String(decryptedCombinedDataBytes).substring
            			(new String(decryptedCombinedDataBytes).length() - 59).getBytes();
		
	    System.out.print(new String(decryptedDataBytes));
            // Calculates and stores the hex representation of the SHA-1 Hash of the decrypted data
            byte[] shaHashBytes = sha1_hash(decryptedDataBytes);

            // Prints out the original and new SHA-1 hashes of the message
            System.out.println("Old SHA-1 Hash: " + new String(decryptedShaHashBytes));
            System.out.println("New SHA-1 Hash: " + toHexString(shaHashBytes));

            // Compares the original and new SHA-1 hashes of the message to determine if the file was tampered with
            if (new String(decryptedShaHashBytes).equals(toHexString(shaHashBytes)))
            {
                System.out.println("File Not Tampered With");
            } else
            {
                System.out.println("File Tampered With!");
            }
        } catch (IllegalBlockSizeException | BadPaddingException e)
        {
            System.out.println("File Tampered With! / Incorrect Seed!");
        } catch (Exception e)
        {
            e.printStackTrace();
        } finally
        {
            try
            {
                if (inputFileStream != null)
                {
                    inputFileStream.close();
                }
            } catch (Exception e2)
            {
                e2.printStackTrace();
            }
        }
    }

    public static byte[] sha1_hash(byte[] input_data) throws Exception
    {
        byte[] hashval = null;
        try
        {
            //create message digest object
            MessageDigest sha1 = MessageDigest.getInstance("SHA1");

            //make message digest
            hashval = sha1.digest(input_data);
        } catch (NoSuchAlgorithmException nsae)
        {
            System.out.println(nsae);
        }
        return hashval;
    }

    /*
     * Converts a byte array to hex string
     * this code from http://java.sun.com/j2se/1.4.2/docs/guide/security/jce/JCERefGuide.html#HmacEx
     */
    public static String toHexString(byte[] block)
    {
        StringBuffer buf = new StringBuffer();

        int len = block.length;

        for (int i = 0; i < len; i++)
        {
            byte2hex(block[i], buf);
            if (i < len - 1)
            {
                buf.append(":");
            }
        }
        return buf.toString();
    }

    /*
     * Converts a byte to hex digit and writes to the supplied buffer
     * this code from http://java.sun.com/j2se/1.4.2/docs/guide/security/jce/JCERefGuide.html#HmacEx
     */
    public static void byte2hex(byte b, StringBuffer buf)
    {
        char[] hexChars = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
        int high = ((b & 0xf0) >> 4);
        int low = (b & 0x0f);
        buf.append(hexChars[high]);
        buf.append(hexChars[low]);
    }
}
