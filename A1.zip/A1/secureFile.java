
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

/*
 * secureFile.java
 * Asjad Malick
 * 30002229
 * CPSC 418 A1
 */

public class secureFile
{
    // Specifies the IV spec for the AES key
    private static byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    private static IvParameterSpec ivSpec = new IvParameterSpec(iv);

    public static void main(String args[])
    {
        // Initializes the data streams for the raw input and encrypted output files
        FileInputStream inputFileStream = null;
        FileOutputStream outputFileStream = null;

        // Surrounds the code with a try / catch statement to handle any errors
        try
        {
            // Creates data streams for the raw input and encrypted output files
            inputFileStream = new FileInputStream(args[0]);
            outputFileStream = new FileOutputStream(args[0]+ "ENC");

            // Reads the input file's raw data into a byte array
            byte[] inputRawDataBytes = new byte[inputFileStream.available()];
            inputFileStream.read(inputRawDataBytes);

            // Calculates and prints out the hex representation of the SHA-1 Hash of the input file
            byte[] shaHashBytes = sha1_hash(inputRawDataBytes);
            System.out.println("SHA-1 Hash: " + toHexString(shaHashBytes));

            // Appends the SHA-1 Hash of the input file to the end of the file's data
            byte[] combinedRawDataBytes = 
            		( new String(inputRawDataBytes) + toHexString(shaHashBytes).toString() ).getBytes();

            // Gets the user defined seed from the command line argument's passed and stores it
            String seed = args[1];
            
            // Gets the byte array of the hash of user defined seed
            byte[] seedHash = sha1_hash(seed.getBytes());

            // Uses the user defined seed to create a 16 byte (128 bit) array
            byte[] seedBytes = Arrays.copyOf(seedHash, 16);

            // Creates a new AES key using the provided byte array of the provided seed
            SecretKey generatedKey = new SecretKeySpec(seedBytes, "AES");

            // Makes a data encrypter
            Cipher encrypt = Cipher.getInstance("AES/CBC/PKCS5Padding");
            encrypt.init(Cipher.ENCRYPT_MODE, generatedKey, ivSpec);

            // Encrypts the byte array of the data
            byte[] encryptedDataBytes = encrypt.doFinal(combinedRawDataBytes);

            // Writes out the encrypted data to a secondary file and closes the file output stream
            outputFileStream.write(encryptedDataBytes);
            outputFileStream.close();
        } catch (Exception e)
        {
            e.printStackTrace();
        } finally // From Demo.java
        {
            try
            {
                if (inputFileStream != null)
                {
                    inputFileStream.close();
                }
                if (outputFileStream != null)
                {
                    outputFileStream.close();
                }
            } catch (Exception e2)
            {
                e2.printStackTrace();
            }
        }
    }

    // From Demo.java
    public static byte[] sha1_hash(byte[] input_data) throws Exception
    {
        byte[] hashval = null;
        try
        {
            //create message digest object
            MessageDigest sha1 = MessageDigest.getInstance("SHA1");

            //make message digest
            hashval = sha1.digest(input_data);
        } catch (NoSuchAlgorithmException nsae)
        {
            System.out.println(nsae);
        }
        return hashval;
    }

    /*
     * Converts a byte array to hex string
     * this code from http://java.sun.com/j2se/1.4.2/docs/guide/security/jce/JCERefGuide.html#HmacEx
     */
    public static String toHexString(byte[] block)
    {
        StringBuffer buf = new StringBuffer();

        int len = block.length;

        for (int i = 0; i < len; i++)
        {
            byte2hex(block[i], buf);
            if (i < len - 1)
            {
                buf.append(":");
            }
        }
        return buf.toString();
    }

    /*
     * Converts a byte to hex digit and writes to the supplied buffer
     * this code from http://java.sun.com/j2se/1.4.2/docs/guide/security/jce/JCERefGuide.html#HmacEx
     */
    public static void byte2hex(byte b, StringBuffer buf)
    {
        char[] hexChars = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
        int high = ((b & 0xf0) >> 4);
        int low = (b & 0x0f);
        buf.append(hexChars[high]);
        buf.append(hexChars[low]);
    }
}
